#Игра в слова версия 0.0.2.0
file_lib_name = ''
file_text_name = ''
info_about_lengv = int(input('select a language(выбери язык) Ru(Рус) = 1 Eng(Англ) = 2: '))
if info_about_lengv == 1:
    file_lib_name = 'libaryRUS.txt'
    file_text_name = 'settingRUS.txt'
elif info_about_lengv == 2:
    file_lib_name = 'libaryENG.txt'
    file_text_name = 'settingENG.txt'
#Чтение файла
main_lib_file = open('lib/'+file_lib_name,'r')
libary_in_game = []
for line in main_lib_file:
    libary_in_game.append(line[:-1])
main_lib_file.close()

main_text_file = open('lib/'+file_text_name,'r')
libary_setting_game = []
for line in main_text_file:
    libary_setting_game.append(line[:-1])
main_text_file.close()    
#Объявление переменных
libary_out_game = []
check_count_course = 0

#Программа
print(libary_setting_game[0])
print(libary_setting_game[1])
print(libary_setting_game[2])
print(libary_setting_game[3])
print(libary_setting_game[4])
name = input(libary_setting_game[5]).strip()
print(libary_setting_game[6] + name + libary_setting_game[7])
print(libary_setting_game[8])
while 0 == 0:
    choice = input(name+":"+"\t").capitalize()
    check_word = 0
    check_count_course += 1
    while check_word != 1:
        last_word_letter = choice[-1]
        first_word_letter = choice[0]
        if check_count_course != 1 and first_word_letter == last_letter_in_word:
            if choice in libary_in_game and not(choice in libary_out_game):
                libary_in_game.pop(libary_in_game.index(choice))
                libary_out_game.append(choice)
                check_word = 1
            elif choice in libary_out_game:
                print(libary_setting_game[9])
                choice = input(name+":"+"\t")
            elif choice == libary_setting_game[18]:
                print(libary_setting_game[19])
                exit(0)
                sys.exit
                os.abort()
            else:
                print(libary_setting_game[10])
                print(libary_setting_game[11])
                check_confirmation = input()
                if check_confirmation == libary_setting_game[12] or check_confirmation == libary_setting_game[13] or check_confirmation == libary_setting_game[14]:
                    check_word = 1
                    main_text_file = open('lib/'+file_lib_name,'a')
                    main_text_file.write(choice+'\n')
                    main_text_file.close()
                    libary_out_game.append(choice)
                else:
                    choice = input(name+":"+"\t")
        elif check_count_course == 1:
            if choice in libary_in_game and not(choice in libary_out_game):
                libary_in_game.pop(libary_in_game.index(choice))
                libary_out_game.append(choice)
                check_word = 1
            elif choice in libary_out_game:
                print(libary_setting_game[9])
                choice = input(name+":"+"\t")
            elif choice == libary_setting_game[18]:
                print(libary_setting_game[19])
                exit(0)
                sys.exit
                os.abort()
            else:
                print(libary_setting_game[10])
                print(libary_setting_game[11])
                check_confirmation = input()
                if check_confirmation == libary_setting_game[12] or check_confirmation == libary_setting_game[13] or check_confirmation == libary_setting_game[14]:
                    check_word = 1
                    main_text_file = open('lib/'+file_lib_name,'a')
                    main_text_file.write(choice+'\n')
                    main_text_file.close()
                    libary_out_game.append(choice)
                else:
                    choice = input(name+":"+"\t")
        else:
            print(libary_setting_game[15]+last_letter_in_word+'"')
            choice = input(name+":"+"\t")
            last_word_letter = choice[-1]
    last_word_letter = choice[-1]
    if last_word_letter == 'ь' or last_word_letter == 'Ь' or last_word_letter == 'ы' or last_word_letter == 'Ы' or last_word_letter == 'Ъ' or last_word_letter == 'ъ':
            last_word_letter = choice[-2]
    check_II_ans = 0
    for word in libary_in_game:
        first_letter_in_word = (word[0]).lower()
        if first_letter_in_word == last_word_letter:
            print(libary_setting_game[16] + word)
            libary_in_game.pop(libary_in_game.index(word))
            libary_out_game.append(word)
            check_II_ans = 1
            break
    if check_II_ans == 0:
        print(libary_setting_game[17])
        break
    else:
        last_letter_in_word = (word[-1]).upper()
        if last_letter_in_word == 'ь' or last_letter_in_word == 'Ь' or last_letter_in_word == 'ы' or last_letter_in_word == 'Ы' or last_letter_in_word == 'Ъ' or last_letter_in_word == 'ъ':
            last_letter_in_word = (word[-2]).upper()
#Конец
