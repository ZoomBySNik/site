#unpacer for libs
Lib = []
file = open('lib/res/libaryRUS.txt','r')
for line in file:
    Lib.append(line[:-1])
file.close()
file = open('lib/libaryRUS.txt','w')
for line in Lib:
    file.write(line+'\n')
    print(line)
file.close()
file = open('lib/res/libaryENG.txt','r')
for line in file:
    Lib.append(line[:-1])
file.close()
file = open('lib/libaryENG.txt','w')
for line in Lib:
    file.write(line+'\n')
    print(line)
file.close()
